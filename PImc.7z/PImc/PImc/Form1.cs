﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double numPeso, numAltura, numImc;
        string classificacao;

        public Form1()
        {
            InitializeComponent();
        }

        private void textAlt_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textAlt.Text, out numAltura))
            {
                MessageBox.Show("Altura inválida. Por favor, insira um número válido.");
                textAlt.Focus();
            }
        }

        private void btnLimpa_Click(object sender, EventArgs e)
        {
            textPeso.Clear();
            textAlt.Clear();
            textImc.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja realmente sair?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            numImc = numPeso / (numAltura * numAltura);
            numImc = Math.Round(numImc, 1);
            if (numImc < 18.5)
            {
                classificacao = "Abaixo do peso";
            }
            else if (numImc >= 18.5 && numImc < 25)
            {
                classificacao = "Peso normal";
            }
            else if (numImc >= 25 && numImc < 30)
            {
                classificacao = "Sobrepeso";
            }
            else if (numImc >= 30 && numImc < 35)
            {
                classificacao = "Obesidade grau I";
            }
            else if (numImc >= 35 && numImc < 40)
            {
                classificacao = "Obesidade grau II";
            }
            else
            {
                classificacao = "Obesidade grau III";
            }
            textImc.Text = numImc.ToString() + " - " + classificacao;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textPeso.Text, out numPeso))
            {
                MessageBox.Show("Peso inválido. Por favor, insira um número válido.");
                textPeso.Focus();
            }

        }
    }
}
