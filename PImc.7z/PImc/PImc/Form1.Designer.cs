﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnLimpa = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.textPeso = new System.Windows.Forms.TextBox();
            this.textAlt = new System.Windows.Forms.TextBox();
            this.textImc = new System.Windows.Forms.TextBox();
            this.lblPeso = new System.Windows.Forms.Label();
            this.lblAlt = new System.Windows.Forms.Label();
            this.lblImc = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(236, 328);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(150, 82);
            this.btnCalc.TabIndex = 0;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnLimpa
            // 
            this.btnLimpa.Location = new System.Drawing.Point(392, 328);
            this.btnLimpa.Name = "btnLimpa";
            this.btnLimpa.Size = new System.Drawing.Size(150, 82);
            this.btnLimpa.TabIndex = 1;
            this.btnLimpa.Text = "Limpar";
            this.btnLimpa.UseVisualStyleBackColor = true;
            this.btnLimpa.Click += new System.EventHandler(this.btnLimpa_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(548, 328);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(150, 82);
            this.btnSair.TabIndex = 2;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // textPeso
            // 
            this.textPeso.Location = new System.Drawing.Point(392, 174);
            this.textPeso.Name = "textPeso";
            this.textPeso.Size = new System.Drawing.Size(175, 26);
            this.textPeso.TabIndex = 3;
            this.textPeso.Validated += new System.EventHandler(this.textPeso_Validated);
            // 
            // textAlt
            // 
            this.textAlt.Location = new System.Drawing.Point(392, 206);
            this.textAlt.Name = "textAlt";
            this.textAlt.Size = new System.Drawing.Size(175, 26);
            this.textAlt.TabIndex = 4;
            this.textAlt.Validated += new System.EventHandler(this.textAlt_Validated);
            // 
            // textImc
            // 
            this.textImc.Enabled = false;
            this.textImc.Location = new System.Drawing.Point(392, 238);
            this.textImc.Name = "textImc";
            this.textImc.Size = new System.Drawing.Size(175, 26);
            this.textImc.TabIndex = 5;
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Location = new System.Drawing.Point(300, 180);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(86, 20);
            this.lblPeso.TabIndex = 6;
            this.lblPeso.Text = "Peso Atual";
            this.lblPeso.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblAlt
            // 
            this.lblAlt.AutoSize = true;
            this.lblAlt.Location = new System.Drawing.Point(335, 209);
            this.lblAlt.Name = "lblAlt";
            this.lblAlt.Size = new System.Drawing.Size(51, 20);
            this.lblAlt.TabIndex = 7;
            this.lblAlt.Text = "Altura";
            // 
            // lblImc
            // 
            this.lblImc.AutoSize = true;
            this.lblImc.Location = new System.Drawing.Point(348, 241);
            this.lblImc.Name = "lblImc";
            this.lblImc.Size = new System.Drawing.Size(38, 20);
            this.lblImc.TabIndex = 8;
            this.lblImc.Text = "IMC";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1211, 643);
            this.Controls.Add(this.lblImc);
            this.Controls.Add(this.lblAlt);
            this.Controls.Add(this.lblPeso);
            this.Controls.Add(this.textImc);
            this.Controls.Add(this.textAlt);
            this.Controls.Add(this.textPeso);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpa);
            this.Controls.Add(this.btnCalc);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnLimpa;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.TextBox textPeso;
        private System.Windows.Forms.TextBox textAlt;
        private System.Windows.Forms.TextBox textImc;
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.Label lblAlt;
        private System.Windows.Forms.Label lblImc;
    }
}

